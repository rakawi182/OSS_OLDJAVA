const {E}=require('./harness.js'); const fs=require('fs');
E.ts.jd_utc_to_tt_extended=function(j){return j;};
const AKM=6378.14, AU=149597870.7, RSUN=696000, D2R=Math.PI/180, K=0.2724880;
function samp(jt){
  const s=E.sun.calculate_sun_position_vsop87d(jt,'equatorial_apparent'), m=E.moon.calculate_position(jt,'equatorial_apparent');
  return {sra:s.ra_rad,sdec:s.dec_rad,sr:s.radius_au,mra:m.equatorial_apparent.ra_deg*D2R,mdec:m.equatorial_apparent.dec_deg*D2R,mr:m.distance_km,dpsi:s.corrections.nutation_dPsi_rad,eps:s.corrections.true_obliquity_rad};
}
function polyfit(ts,ys,deg){ const n=deg+1,A=Array.from({length:n},()=>new Array(n+1).fill(0));
  for(let i=0;i<ts.length;i++){ const p=[1]; for(let j=1;j<=2*deg;j++) p[j]=p[j-1]*ts[i]; for(let r=0;r<n;r++){ for(let c=0;c<n;c++) A[r][c]+=p[r+c]; A[r][n]+=ys[i]*p[r]; } }
  for(let c=0;c<n;c++){ let piv=c; for(let r=c+1;r<n;r++) if(Math.abs(A[r][c])>Math.abs(A[piv][c])) piv=r; [A[c],A[piv]]=[A[piv],A[c]]; for(let r=0;r<n;r++) if(r!==c){ const f=A[r][c]/A[c][c]; for(let k=c;k<=n;k++) A[r][k]-=f*A[c][k]; } }
  return A.map((row,i)=>row[n]/row[i]); }
const pv=(c,t)=>{let v=0;for(let i=c.length-1;i>=0;i--)v=v*t+c[i];return v;};
const gast=(jdut,dpsi,eps)=>{const T=(jdut-2451545)/36525; return (280.46061837+360.98564736629*(jdut-2451545)+0.000387933*T*T-T*T*T/38710000)*D2R+dpsi*Math.cos(eps);};
function solveL(row,dtA,dtB){
  const jd0=E.ts.date_to_jd_utc(row.y,row.m,row.d,0,0,0,0)+row.sec/86400;
  const N=10, W=0.5, taus=[], S={sra:[],sdec:[],sr:[],mra:[],mdec:[],mr:[]}; let last, po={s:null,m:null}, off={s:0,m:0};
  for(let i=-N;i<=N;i++){ const tau=i*W, q=samp(jd0+tau/24); last=q; taus.push(tau);
    for(const [key,ang] of [['sra','s'],['mra','m']]){ let a=q[key]+off[ang]; if(po[ang]!==null){ while(a-po[ang]>Math.PI){a-=2*Math.PI;off[ang]-=2*Math.PI;} while(a-po[ang]<-Math.PI){a+=2*Math.PI;off[ang]+=2*Math.PI;} } po[ang]=a; S[key].push(a); }
    S.sdec.push(q.sdec); S.sr.push(q.sr); S.mdec.push(q.mdec); S.mr.push(q.mr); }
  const deg=6, C={}; for(const k of Object.keys(S)) C[k]=polyfit(taus,S[k],deg);
  const geo=(t)=>{ const sra=pv(C.sra,t),sde=pv(C.sdec,t),sr=pv(C.sr,t),mra=pv(C.mra,t),mde=pv(C.mdec,t),mr=pv(C.mr,t);
    const sv=[Math.cos(sde)*Math.cos(sra),Math.cos(sde)*Math.sin(sra),Math.sin(sde)], mv=[Math.cos(mde)*Math.cos(mra),Math.cos(mde)*Math.sin(mra),Math.sin(mde)];
    const av=[-sv[0],-sv[1],-sv[2]]; const dot=mv[0]*av[0]+mv[1]*av[1]+mv[2]*av[2];
    const cr=[mv[1]*av[2]-mv[2]*av[1],mv[2]*av[0]-mv[0]*av[2],mv[0]*av[1]-mv[1]*av[0]]; const rho=Math.atan2(Math.hypot(...cr),dot);
    const Pm=Math.asin(AKM/mr), Ps=Math.asin(AKM/(sr*AU)), Ss=Math.asin(RSUN/(sr*AU)), sm=Math.asin(K*Math.sin(Pm));
    const Rp=1.01*Pm+Ss+Ps, Ru=1.01*Pm-Ss+Ps;
    return {rho,Pm,Rp,Ru,sm,mv,av,mra,mde,mr,sra,sde}; };
  const f=t=>geo(t).rho;
  let best=0,bv=9; for(let t=-3;t<=3;t+=0.005){ const v=f(t); if(v<bv){bv=v;best=t;} }
  let lo=best-0.005,hi=best+0.005; for(let it=0;it<60;it++){ const a=lo+(hi-lo)*0.381966,b=hi-(hi-lo)*0.381966; if(f(a)<f(b)) hi=b; else lo=a; }
  const tm=(lo+hi)/2, g=geo(tm), rho=g.rho;
  // signed gamma (Earth radii at Moon distance); + when Moon north of shadow axis
  const aa=Math.atan2(g.av[1],g.av[0]), ad=Math.asin(g.av[2]); const nv=[-Math.sin(ad)*Math.cos(aa),-Math.sin(ad)*Math.sin(aa),Math.cos(ad)];
  const sgn=(g.mv[0]*nv[0]+g.mv[1]*nv[1]+g.mv[2]*nv[2])>=0?1:-1; const gamma=sgn*g.mr*Math.sin(rho)/AKM;
  const pmag=(g.Rp-rho+g.sm)/(2*g.sm), umag=(g.Ru-rho+g.sm)/(2*g.sm);
  const out={dTD:tm*3600,gamma,pmag,umag};
  out.type = umag>=1?'T':(umag>0?'P':'N'); if(pmag<=0) out.type='-';
  const root=(fn,sign)=>{ // find crossing of fn(t)=0 going outward from tm; fn(tm)<0 inside
    if(fn(tm)>=0) return null; let a=tm,b=tm+sign*6; if(fn(b)<0) return null; for(let it=0;it<60;it++){ const m=(a+b)/2; if(fn(m)<0) a=m; else b=m; } return (a+b)/2; };
  const dur=(radfn)=>{ const t1=root(radfn,-1),t2=root(radfn,1); return (t1===null||t2===null)?null:(t2-t1)*60; };
  out.pen=dur(t=>{const q=geo(t);return q.rho-(q.Rp+q.sm);});
  out.par=dur(t=>{const q=geo(t);return q.rho-(q.Ru+q.sm);});
  out.tot=dur(t=>{const q=geo(t);return q.rho-(q.Ru-q.sm);});
  // sub-lunar point at greatest eclipse
  const jdm=jd0+tm/24; out.lat=g.mde/D2R;
  const wrap=x=>((x+180)%360+360)%360-180;
  out.lonA=wrap((g.mra-gast(jdm-dtA/86400,last.dpsi,last.eps))/D2R); out.lonB=wrap((g.mra-gast(jdm-dtB/86400,last.dpsi,last.eps))/D2R);
  // polynomial fit quality: compare to direct engine at tm
  if(row._chk){ const q=samp(jdm); const d=geo(tm); out.fitErrArcsec=Math.hypot((q.mra-d.mra)*Math.cos(q.mdec),(q.mdec-d.mde))/D2R*3600; }
  return out;
}
module.exports={solveL,E};
if(require.main===module){
  const rows=JSON.parse(fs.readFileSync('lunar.json')); const r=rows.find(x=>x.y===2018&&x.m===7); r._chk=1;
  const o=solveL(r,r.dt,r.dt); console.log(JSON.stringify(r)); console.log(JSON.stringify(o));
}
