const {solveL,E}=require('./lunar.js'); const fs=require('fs');
const rows=JSON.parse(fs.readFileSync('lunar.json')).filter(r=>r.y>=500&&r.y<=1500);
const out=fs.openSync('lunar_out.jsonl','w'); const t0=Date.now(); const wrap=x=>((x+180)%360+360)%360-180;
const tl=t=>t[0]==='T'?'T':t[0]==='P'?'P':'N';
rows.forEach((r,i)=>{ const jd0=E.ts.date_to_jd_utc(r.y,r.m,r.d,0,0,0,0)+r.sec/86400; const dtO=E.ts.get_delta_t(jd0);
  let o; try{ o=solveL(r,r.dt,dtO); }catch(e){ o={err:e.message}; }
  const rec={i,cat:r.cat,y:r.y,m:r.m,d:r.d,type:tl(r.type),dtCat:r.dt,dtOss:dtO};
  if(!o.err){ Object.assign(rec,{typeOss:o.type,dTD:o.dTD,dgam:o.gamma-r.gamma,dpm:o.pmag-r.pmag,dum:o.umag-r.umag});
    if(o.pen!==null&&r.pen!==null) rec.dpen=o.pen-r.pen; if(o.par!==null&&r.par!==null) rec.dpar=o.par-r.par; if(o.tot!==null&&r.tot!==null) rec.dtot=o.tot-r.tot;
    rec.dlat=o.lat-r.lat; rec.dlonCat=wrap(o.lonA-r.lon); rec.dlonOss=wrap(o.lonB-r.lon); }
  else rec.err=o.err;
  fs.writeSync(out,JSON.stringify(rec)+'\n'); });
console.error('done s',(Date.now()-t0)/1000);
