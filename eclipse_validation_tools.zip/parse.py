import re,json
MON={m:i+1 for i,m in enumerate('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split())}
def rd(p): return open(p,encoding='latin-1').read().replace('\r','').split('\n')
def num(x):
    try: return float(x)
    except: return None
def ll(a,b):
    la=num(a[:-1])*(1 if a[-1]=='N' else -1); lo=num(b[:-1])*(1 if b[-1]=='E' else -1); return la,lo
sol=[]
for l in rd('/mnt/user-data/uploads/5MKSEcatalog.txt'):
    m=re.match(r'^\s*(\d+)\s+(\d+)\s+(-?\d+) (\w{3})\s+(\d+)\s+(\d\d):(\d\d):(\d\d)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(\S+)\s+(\S+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*(.*)$',l)
    if not m: continue
    y=int(m.group(3))
    if not (500<=y<=1500 or 1900<=y<=2030): continue
    g=m.groups(); t=g[15].split()
    r={'cat':int(g[0]),'y':y,'m':MON[g[3]],'d':int(g[4]),'sec':int(g[5])*3600+int(g[6])*60+int(g[7]),'dt':int(g[8]),'saros':int(g[10]),'type':g[11],'qle':g[12],'gamma':float(g[13]),'mag':float(g[14])}
    if len(t)>=2:
        r['lat'],r['lon']=ll(t[0],t[1])
        if len(t)>2 and re.fullmatch(r'-?\d+',t[2]): r['alt']=int(t[2])
        if len(t)>4 and re.fullmatch(r'\d+',t[4]): r['width']=int(t[4])
        dm=re.match(r'(\d+)m(\d+)s',t[-1])
        if dm: r['dur']=int(dm.group(1))*60+int(dm.group(2))
    sol.append(r)
json.dump(sol,open('solar.json','w'))
print(len(sol),sum(1 for r in sol if 500<=r['y']<=1500)); print([r for r in sol if r['y']==2017])
