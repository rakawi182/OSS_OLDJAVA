import json,re,statistics as st
S=[json.loads(l) for l in open('solar_out.jsonl')]; Lr=[json.loads(l) for l in open('lunar_out.jsonl')]
V=json.load(open('eclipse_validation.json'))
# dT difference bands (OSS minus NASA catalog), solar+lunar together
dT=[]
for lo in range(500,1500,100):
    x=[r['dtOss']-r['dtCat'] for r in S+Lr if lo<=r['y']<lo+100 and 'err' not in r]
    dT.append([lo,lo+100,round(st.mean(x),1),round(min(x),1),round(max(x),1),len(x)])
V['bands']['dT']=dT; V['meta']['dTnote']='dT_OSS (default model, MSH2020) minus dT_NASA (Morrison-Stephenson 2004 + c); longitude shift = diff/240 deg'
txt=json.dumps(V,separators=(',',':'),ensure_ascii=False); assert '</script' not in txt
html=open('/mnt/user-data/outputs/OSS_OLDJAVA_R2026_11.html',encoding='utf-8').read()
assert 'id="eclipse-validation"' not in html
def rep(a,b):
    global html
    assert html.count(a)==1,(a[:60],html.count(a)); html=html.replace(a,b)
# 1) data block right after ecat-data
i=html.index('<script type="text/plain" id="ecat-data">'); j=html.index('</script>',i)+len('</script>')
html=html[:j]+'\n<script type="text/plain" id="eclipse-validation">'+txt+'</script>'+html[j:]
# 2) placeholder + init call
rep('<div id="au-ec2"></div>','<div id="au-ec2"></div><div id="au-nv"></div>')
rep("  initConclusion();\n  /* progress bar","  initConclusion();\n  initEclipseNasa();\n  /* progress bar")
code=r'''
  /* Validasi gerhana NASA 500-1500 M: hasil dihitung di luar browser (blok eclipse-validation), tab hanya menampilkan */
  function initEclipseNasa() {
    var box = document.getElementById('au-nv'); if (!box) return;
    var V; try { V = JSON.parse(App.T('eclipse-validation')); } catch (e) { return; }
    var f = function (x, d) { return x == null ? '\u2013' : Number(x).toFixed(d); }, m = V.meta, B = V.bands;
    var h = '<div class="card"><h3>Validasi gerhana NASA \u00b7 500\u20131500 M</h3>';
    h += '<p class="caption">Mesin OSS (VSOP87D + ELP82B, percepatan sekuler Bulan \u221225,858\u2033/abad\u00b2) dijalankan di luar browser untuk ' + m.solar.n + ' gerhana Matahari dan ' + m.lunar.n + ' gerhana Bulan, lalu dibandingkan dengan katalog NASA Five Millennium (Espenak &amp; Meeus). Tanda selisih: OSS \u2212 NASA. Waktu, gamma, magnitudo, dan durasi dihitung dalam TD sehingga <b>tidak bergantung pada \u0394T</b>; hanya bujur yang bergantung pada \u0394T.</p>';
    h += '<p class="caption">Kesesuaian jenis gerhana: Matahari ' + m.typeAgree.solar[0] + '/' + m.typeAgree.solar[1] + ' \u00b7 Bulan ' + m.typeAgree.lunar[0] + '/' + m.typeAgree.lunar[1] + '. Hasil sampel acuan: 2017-08-21 selisih waktu 0,19 s, 2018-07-27 selisih 0,25 s.</p>';
    h += '<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Rentang</th><th>Matahari |\u0394TD| s</th><th>|\u0394\u03b3|</th><th>|\u0394mag|</th><th>Bulan |\u0394TD| s</th><th>|\u0394\u03b3|</th><th>|\u0394mag umbra|</th><th>\u0394T OSS\u2212NASA s</th><th>\u0394bujur\u00b0</th></tr></thead><tbody>';
    for (var i = 0; i < B.solar.length; i++) {
      var s = B.solar[i][2], l = B.lunar[i][2], t = B.dT[i];
      h += '<tr><td>' + B.solar[i][0] + '\u2013' + B.solar[i][1] + '</td><td>' + f(s.dTD[0], 1) + '</td><td>' + f(s.dgam[0], 4) + '</td><td>' + f(s.dmag[0], 4) + '</td><td>' + f(l.dTD[0], 1) + '</td><td>' + f(l.dgam[0], 4) + '</td><td>' + f(l.dum[0], 4) + '</td><td>' + f(t[2], 0) + '</td><td>' + f(t[2] / 240, 2) + '</td></tr>';
    }
    h += '</tbody></table></div><p class="caption">Nilai = median selisih mutlak per 100 tahun (p95 dan maksimum ada di blok data). \u0394bujur = rata-rata (\u0394T OSS \u2212 \u0394T NASA)/240.</p>';
    h += '<p class="caption"><b>Temuan:</b> selisih tumbuh kira-kira sebanding T\u00b2 (T abad dari 2000), tanda selisih gamma berbalik menurut jenis simpul (Saros ganjil/genap), dan pola yang sama muncul pada gerhana Matahari dan Bulan. Ini menunjuk ke beda fase orbit Bulan terhadap argumen rata-rata hasil perbaikan NASA (Chapront dkk. 2002); penyebab pastinya belum diverifikasi. Besarnya masih di bawah ketidakpastian \u0394T pada periode ini. Lintang/bujur titik maksimum gerhana non-sentral dan parsial kurang andal.</p>';
    h += '<div class="grid3"><div><label>Cari tahun (500\u20131500)</label><input id="au-nv-y" type="number" min="500" max="1500" step="1" value="1000"></div><div><label>&nbsp;</label><button class="primary" id="au-nv-go">Tampilkan gerhana tahun itu</button></div></div><div id="au-nv-out"></div></div>';
    box.innerHTML = h;
    var EC = null;
    function dec(txt) { var rs = txt.split(';'), t = 0, o = new Array(rs.length); for (var i = 0; i < rs.length; i++) { var r = rs[i].split(','); t += parseInt(r[0], 10); o[i] = { t: t, r: r }; } return o; }
    document.getElementById('au-nv-go').onclick = function () {
      var out = document.getElementById('au-nv-out'), y = parseInt(document.getElementById('au-nv-y').value, 10);
      if (!(y >= 500 && y <= 1500)) { out.innerHTML = '<p class="dim">Masukkan tahun 500\u20131500.</p>'; return; }
      try {
        if (!EC) { var D = JSON.parse(App.T('ecat-data')); EC = { S: dec(D.SE), L: dec(D.LE), U: D.meta.K0 }; }
        var ts = App.engines.ts, rows = [];
        [['S', V.SV, m.solar, ['P', 'A', 'T', 'H'], 'Matahari'], ['L', V.LV, m.lunar, ['N', 'P', 'T'], 'Bulan']].forEach(function (g) {
          var R = g[1].split(';'), first = g[2].first, n = g[2].n, E = EC[g[0]];
          for (var k = 0; k < n; k++) {
            var e = E[first - 1 + k], jd = 2451545 + e.t / 86400, d = ts.jd_to_gregorian(jd);
            if (d.year_astronomical !== y) continue;
            var q = R[k].split(','), N = e.r, sol = g[0] === 'S', dtc = parseFloat(N[sol ? 10 : 11]), dto = ts.get_delta_t(jd);
            rows.push({ jd: jd, h: '<tr><td>' + y + '-' + String(d.month).padStart(2, '0') + '-' + String(d.day).padStart(2, '0') + (d.calendar === 'Julian' ? ' J' : ' G') + '</td><td>' + g[4] + '</td><td>' + N[2].charAt(0) + '\u2192' + g[3][parseInt(q[0], 10)] + '</td><td>' + N[3] + '</td><td>' + (q[2] === '' ? '\u2013' : (q[2] / 1e4).toFixed(4)) + '</td><td>' + (q[1] === '' ? '\u2013' : q[1]) + '</td><td>' + (sol ? (q[3] === '' ? '\u2013' : (q[3] / 1e4).toFixed(4)) : (q[4] === '' ? '\u2013' : (q[4] / 1e4).toFixed(4))) + '</td><td>' + f(dtc, 0) + '</td><td>' + f((dto - dtc) / 240, 2) + '</td></tr>' });
          }
        });
        rows.sort(function (a, b) { return a.jd - b.jd; });
        out.innerHTML = rows.length ? '<div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Tanggal (J/G)</th><th>Jenis</th><th>NASA\u2192OSS</th><th>\u03b3 NASA</th><th>\u0394\u03b3</th><th>\u0394TD s</th><th>\u0394mag</th><th>\u0394T NASA s</th><th>\u0394bujur\u00b0 (\u0394T OSS)</th></tr></thead><tbody>' + rows.map(function (r) { return r.h; }).join('') + '</tbody></table></div><p class="caption">\u0394mag: gerhana Bulan = magnitudo umbra. Tanggal kalender Julian (J) sebelum 1582, Gregorian (G) sesudahnya; waktu dalam TD.</p>' : '<p class="dim">Tidak ada gerhana pada tahun itu dalam katalog.</p>';
      } catch (err) { out.innerHTML = '<p class="dim">Gagal menampilkan: ' + String(err && err.message || err) + '</p>'; }
    };
  }
'''
rep("  function metric(t, v) { return App.metric ? App.metric(t, v)",code+"\n  function metric(t, v) { return App.metric ? App.metric(t, v)")
open('/tmp/ecl/patched.html','w',encoding='utf-8').write(html)
print('size',len(html.encode()),'orig',len(open('/mnt/user-data/outputs/OSS_OLDJAVA_R2026_11.html',encoding='utf-8').read().encode()),'block',len(txt))
