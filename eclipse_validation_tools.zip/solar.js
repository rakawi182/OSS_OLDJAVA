const {E}=require('./harness.js');
const fs=require('fs');
E.ts.jd_utc_to_tt_extended=function(j){return j;};   // all inputs are TT/TD
const AKM=6378.14, AU=149597870.7, RSUN=696000, F=1/298.257, D2R=Math.PI/180;
const KU=0.272281, KP=0.2724880;
function body(jt){
  const s=E.sun.calculate_sun_position_vsop87d(jt,'equatorial_apparent');
  const m=E.moon.calculate_position(jt,'equatorial_apparent');
  return {s,m,
    sra:s.ra_rad,sdec:s.dec_rad,sr:s.radius_au*AU/AKM,
    mra:m.equatorial_apparent.ra_deg*D2R,mdec:m.equatorial_apparent.dec_deg*D2R,mr:m.distance_km/AKM,
    dpsi:s.corrections.nutation_dPsi_rad,eps:s.corrections.true_obliquity_rad};
}
const vec=(ra,de,r)=>[r*Math.cos(de)*Math.cos(ra),r*Math.cos(de)*Math.sin(ra),r*Math.sin(de)];
function elements(jt,k){
  const b=body(jt), S=vec(b.sra,b.sdec,b.sr), M=vec(b.mra,b.mdec,b.mr);
  const Z=[S[0]-M[0],S[1]-M[1],S[2]-M[2]], g=Math.hypot(...Z), z=Z.map(v=>v/g);
  const a=Math.atan2(z[1],z[0]), d=Math.asin(z[2]);
  const xh=[-Math.sin(a),Math.cos(a),0], yh=[-Math.sin(d)*Math.cos(a),-Math.sin(d)*Math.sin(a),Math.cos(d)];
  const dot=(u,v)=>u[0]*v[0]+u[1]*v[1]+u[2]*v[2];
  const x=dot(M,xh), y=dot(M,yh), zm=dot(M,z);
  const Rs=RSUN/AKM;
  const sf1=(Rs+k)/g, sf2=(Rs-k)/g, tf1=sf1/Math.sqrt(1-sf1*sf1), tf2=sf2/Math.sqrt(1-sf2*sf2);
  return {x,y,d,a,l1:zm*tf1+k/Math.sqrt(1-sf1*sf1), l2:zm*tf2-k/Math.sqrt(1-sf2*sf2), tf1,tf2,dpsi:b.dpsi,eps:b.eps};
}
// least squares polynomial fit in tau (hours)
function polyfit(ts,ys,deg){
  const n=deg+1, A=Array.from({length:n},()=>new Array(n+1).fill(0));
  for(let i=0;i<ts.length;i++){ const p=[1]; for(let j=1;j<=2*deg;j++) p[j]=p[j-1]*ts[i];
    for(let r=0;r<n;r++){ for(let c=0;c<n;c++) A[r][c]+=p[r+c]; A[r][n]+=ys[i]*p[r]; } }
  for(let c=0;c<n;c++){ let piv=c; for(let r=c+1;r<n;r++) if(Math.abs(A[r][c])>Math.abs(A[piv][c])) piv=r; [A[c],A[piv]]=[A[piv],A[c]];
    for(let r=0;r<n;r++) if(r!==c){ const f=A[r][c]/A[c][c]; for(let k2=c;k2<=n;k2++) A[r][k2]-=f*A[c][k2]; } }
  return A.map((row,i)=>row[n]/row[i]);
}
const pv=(c,t)=>{let v=0;for(let i=c.length-1;i>=0;i--)v=v*t+c[i];return v;};
function gast(jdut,dpsi,eps){ // rad
  const T=(jdut-2451545)/36525;
  let th=280.46061837+360.98564736629*(jdut-2451545)+0.000387933*T*T-T*T*T/38710000;
  th=th*D2R+dpsi*Math.cos(eps); return th;
}
function solve(row,dtUse,dtAlt,kForce){
  const jd0=E.ts.date_to_jd_utc(row.y,row.m,row.d,0,0,0,0)+row.sec/86400;   // catalog TD
  const central=(row.type[0]!=='P');
  const k=(typeof kForce==='number')?kForce:(central?KU:KP);
  const taus=[],X=[],Y=[],L1=[],L2=[],Dd=[],Aa=[]; let prevA=null,off=0;
  for(let i=-6;i<=6;i++){ const tau=i*0.5, e=elements(jd0+tau/24,k);
    let a=e.a+off; if(prevA!==null){ while(a-prevA>Math.PI){a-=2*Math.PI;off-=2*Math.PI;} while(a-prevA<-Math.PI){a+=2*Math.PI;off+=2*Math.PI;} }
    prevA=a; taus.push(tau);X.push(e.x);Y.push(e.y);L1.push(e.l1);L2.push(e.l2);Dd.push(e.d);Aa.push(a); var last=e; }
  const deg=4, cx=polyfit(taus,X,deg), cy=polyfit(taus,Y,deg), c1=polyfit(taus,L1,deg), c2=polyfit(taus,L2,deg), cd=polyfit(taus,Dd,deg), ca=polyfit(taus,Aa,deg);
  const g2=t=>{const x=pv(cx,t),y=pv(cy,t);return x*x+y*y;};
  // scan then golden
  let best=0,bv=1e9; for(let t=-3;t<=3;t+=0.01){ const v=g2(t); if(v<bv){bv=v;best=t;} }
  let lo=best-0.01,hi=best+0.01; for(let it=0;it<60;it++){ const m1=lo+(hi-lo)*0.381966,m2=hi-(hi-lo)*0.381966; if(g2(m1)<g2(m2)) hi=m2; else lo=m1; }
  const tm=(lo+hi)/2, xm=pv(cx,tm), ym=pv(cy,tm), gam=Math.sqrt(xm*xm+ym*ym)*(ym>=0?1:-1);
  const jdm=jd0+tm/24, l1=pv(c1,tm), l2=pv(c2,tm), dm=pv(cd,tm), am=pv(ca,tm);
  const out={dtSec:(jdm-jd0)*86400, gamma:gam, l1,l2};
  const f2=(1-F)**2, kk=1/f2-1, sd=Math.sin(dm), cdd=Math.cos(dm);
  // surface point under axis
  function axisPoint(x,y,d,a){ const s=Math.sin(d),c=Math.cos(d); const A=1+kk*s*s, B=kk*y*c*s, C=x*x+y*y+kk*y*y*c*c-1; const disc=B*B-A*C; if(disc<0) return null;
    const zeta=(-B+Math.sqrt(disc))/A; return zeta; }
  const zetaM=axisPoint(xm,ym,dm,am);
  const bmin=Math.sqrt(1-(2*F-F*F)*cdd*cdd);
  if(zetaM!==null){
    const L1=l1-zetaM*pv([0],0)*0; // placeholder
  }
  // magnitude
  const tf1=last.tf1, tf2=last.tf2;
  if(zetaM!==null){ const L1m=l1-zetaM*tf1, L2m=l2-zetaM*tf2; out.mag=(L1m-L2m)/(L1m+L2m); out.L2=L2m; out.onEarth=true;
    // location
    const jdut=jdm-dtUse/86400; const th=gast(jdut,last.dpsi,last.eps);
    const xh=[-Math.sin(am),Math.cos(am),0], yh=[-sd*Math.cos(am),-sd*Math.sin(am),cdd], zh=[cdd*Math.cos(am),cdd*Math.sin(am),sd];
    const V=[0,1,2].map(i=>xm*xh[i]+ym*yh[i]+zetaM*zh[i]);
    const rxy=Math.hypot(V[0],V[1]); const phip=Math.atan2(V[2],rxy); out.lat=Math.atan(Math.tan(phip)/f2)/D2R;
    let lon=(Math.atan2(V[1],V[0])-th)/D2R; lon=((lon+180)%360+360)%360-180; out.lon=lon; { const th2=gast(jdm-dtAlt/86400,last.dpsi,last.eps); let l2b=(Math.atan2(V[1],V[0])-th2)/D2R; out.lonAlt=((l2b+180)%360+360)%360-180; }
    // duration: observer fixed on Earth, numerical rate
    const obs=(tt)=>{ const aa=pv(ca,tt), dd=pv(cd,tt), jut=jd0+tt/24-dtUse/86400; const t2=gast(jut,last.dpsi,last.eps)-aa; const H=t2+out.lon*D2R;
      const u=Math.atan(f2*Math.tan(out.lat*D2R)), rs=f2*Math.sin(u)*1.0, rc=Math.cos(u); // rho sin/cos geocentric (h=0)
      const rsn=(1-F)*Math.sin(u), rcn=Math.cos(u);
      const xi=rcn*Math.sin(H), eta=rsn*Math.cos(dd)-rcn*Math.cos(H)*Math.sin(dd), ze=rsn*Math.sin(dd)+rcn*Math.cos(H)*Math.cos(dd); return [xi,eta,ze]; };
    const h=1/3600/3, o1=obs(tm+h), o0=obs(tm-h);
    const vx=(pv(cx,tm+h)-pv(cx,tm-h)-(o1[0]-o0[0]))/(2*h), vy=(pv(cy,tm+h)-pv(cy,tm-h)-(o1[1]-o0[1]))/(2*h);
    const n=Math.hypot(vx,vy); out.dur=Math.abs(2*out.L2/n)*3600;
    // hybrid test: L2 sign along central line
    let sMin=1e9,sMax=-1e9;
    for(let t=-3;t<=3;t+=0.02){ const xx=pv(cx,t),yy=pv(cy,t); const z=axisPoint(xx,yy,pv(cd,t),0); if(z===null) continue; const L2=pv(c2,t)-z*tf2; if(L2<sMin)sMin=L2; if(L2>sMax)sMax=L2; }
    out.L2min=sMin; out.L2max=sMax;
    out.type=(sMin<0&&sMax>0)?'H':(L2m<0?'T':'A');
  } else {
    // non-central or partial: nearest point on limb ellipse
    let bt=0,bd=1e9; for(let q=0;q<3600;q++){ const th=q*Math.PI/1800; const dx=xm-Math.cos(th), dy=ym-bmin*Math.sin(th); const dd2=dx*dx+dy*dy; if(dd2<bd){bd=dd2;bt=th;} }
    let a1=bt-0.002,a2=bt+0.002; for(let it=0;it<50;it++){ const m1=a1+(a2-a1)*0.381966,m2=a2-(a2-a1)*0.381966; const f=(th)=>{const dx=xm-Math.cos(th),dy=ym-bmin*Math.sin(th);return dx*dx+dy*dy;}; if(f(m1)<f(m2)) a2=m2; else a1=m1; }
    const th=(a1+a2)/2, m=Math.sqrt((xm-Math.cos(th))**2+(ym-bmin*Math.sin(th))**2);
    out.m=m; out.L2=l2; out.mag=(Math.abs(l2)>m)?(l1-l2)/(l1+l2):(l1-m)/(l1+l2);
    out.type=(Math.abs(l2)>m? (l2<0?'T':'A'):'P'); // coarse; refined below by caller if needed
    const xe=Math.cos(th),ye=bmin*Math.sin(th);
    // location of that limb point (zeta=0)
    const jdut=jdm-dtUse/86400, thg=gast(jdut,last.dpsi,last.eps);
    const xh=[-Math.sin(am),Math.cos(am),0], yh=[-sd*Math.cos(am),-sd*Math.sin(am),cdd];
    const V=[0,1,2].map(i=>xe*xh[i]+ye*yh[i]); const rxy=Math.hypot(V[0],V[1]); out.lat=Math.atan(Math.atan2(V[2],rxy)>0?Math.tan(Math.atan2(V[2],rxy))/f2:Math.tan(Math.atan2(V[2],rxy))/f2)/D2R;
    let lon=(Math.atan2(V[1],V[0])-thg)/D2R; out.lon=((lon+180)%360+360)%360-180; { const th2=gast(jdm-dtAlt/86400,last.dpsi,last.eps); let l2b=(Math.atan2(V[1],V[0])-th2)/D2R; out.lonAlt=((l2b+180)%360+360)%360-180; }
  }
  return out;
}
function solveBlind(row,dt,dtAlt){ let r=solve(row,dt,dtAlt,KU); if(r.type==='P'){ const r2=solve(row,dt,dtAlt,KP); if(r2.type==='P') r=r2; } return r; }
module.exports={solve,solveBlind,E};
if(require.main===module){
  const rows=JSON.parse(fs.readFileSync('solar.json'));
  const sel=rows.filter(r=>r.y===2017&&r.m===8);
  for(const r of sel){ const t0=Date.now(); const o=solveBlind(r,r.dt,r.dt); console.log('ms',Date.now()-t0);
    console.log(JSON.stringify(r)); console.log(JSON.stringify(o)); }
}
