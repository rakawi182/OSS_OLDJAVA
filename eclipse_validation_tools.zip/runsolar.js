const {solveBlind,E}=require('./solar.js'); const fs=require('fs');
const rows=JSON.parse(fs.readFileSync('solar.json')).filter(r=>r.y>=500&&r.y<=1500);
const lim=+process.argv[2]||rows.length, start=+process.argv[3]||0;
const out=fs.openSync(process.argv[4]||'solar_out.jsonl','w'); let t0=Date.now();
const wrap=x=>((x+180)%360+360)%360-180;
for(let i=start;i<Math.min(rows.length,start+lim);i++){ const r=rows[i];
  const jd0=E.ts.date_to_jd_utc(r.y,r.m,r.d,0,0,0,0)+r.sec/86400;
  const dtO=E.ts.get_delta_t(jd0);
  let o; try{ o=solveBlind(r,r.dt,dtO); }catch(e){ o={err:e.message}; }
  const rec={i,cat:r.cat,y:r.y,m:r.m,d:r.d,type:r.type[0],dtCat:r.dt,dtOss:dtO};
  if(!o.err){ Object.assign(rec,{typeOss:o.type,dTD:o.dtSec,dgam:o.gamma-r.gamma,mag:o.mag,dmag:o.mag-r.mag});
    if(r.lat!==undefined&&o.lat!==undefined){ rec.dlat=o.lat-r.lat; rec.dlonCat=wrap(o.lon-r.lon); rec.dlonOss=wrap(o.lonAlt-r.lon); rec.lonOss=o.lonAlt; rec.lon=o.lon; rec.lat=o.lat; }
    if(o.dur!==undefined&&r.dur!==undefined) rec.ddur=o.dur-r.dur; }
  else rec.err=o.err;
  fs.writeSync(out,JSON.stringify(rec)+'\n'); if(i%100===0) console.error('i',i,'elapsed s',(Date.now()-t0)/1000); }
console.error('done',(Date.now()-t0)/1000);
