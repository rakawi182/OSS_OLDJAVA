Validasi gerhana OSS vs katalog NASA (500-1500 M), dijalankan di luar browser.
Butuh: Node.js (v18+), Python 3.
1) Letakkan di satu folder: berkas OSS html, 5MKSEcatalog.txt, 5MKLEcatalog.txt.
2) Edit jalur pada: harness.js (default OSSHTML), parse.py dan parse_l.py (jalur katalog), embed.py (jalur berkas OSS).
   Harness membaca berkas OSS lewat variabel lingkungan OSSHTML.
3) python3 parse.py ; python3 parse_l.py        -> solar.json, lunar.json
4) node runsolar.js 100000 0 solar_out.jsonl     (+-2 menit)
   node runlunar.js                              (+-4 menit) -> lunar_out.jsonl
5) Susun eclipse_validation.json (ringkasan pita + baris per gerhana, lihat embed.py), lalu embed.py menanamnya sebagai blok
   <script type="text/plain" id="eclipse-validation"> dan kartu di tab Audit.
Konvensi: selisih = OSS - NASA. Jenis: Matahari 0P 1A 2T 3H; Bulan 0N 1P 2T. Indeks ecat-data = nomor katalog - 1.
Gerhana Matahari: elemen Besselian (polinom derajat 4, +-3 jam), k=0.272281 (umbra) / 0.2724880 (penumbra).
Gerhana Bulan: pembesaran bayangan Danjon 1.01, k=0.2724880.
Setelah memperbarui EOP, update_eop.py tidak terpengaruh (hanya menyentuh blok eop-data dan tabel LS).
