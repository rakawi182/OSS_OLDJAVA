import re,json,collections
MON={m:i+1 for i,m in enumerate('Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split())}
L=open('/mnt/user-data/uploads/5MKLEcatalog.txt',encoding='latin-1').read().replace('\r','').split('\n')
rows=[]; types=collections.Counter()
for l in L:
    m=re.match(r'^\s*(\d+)\s+(-?\d+) (\w{3})\s+(\d+)\s+(\d\d):(\d\d):(\d\d)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(\S+)\s+(\S+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*$',l)
    if not m: continue
    g=m.groups(); y=int(g[1])
    if not (500<=y<=1500 or 1900<=y<=2030): continue
    num=lambda x: None if x=='-' else float(x)
    def ll(a):
        mm=re.fullmatch(r'(\d+)([NSEW])',a); 
        return None if not mm else int(mm.group(1))*(1 if mm.group(2) in 'NE' else -1)
    r={'cat':int(g[0]),'y':y,'m':MON[g[2]],'d':int(g[3]),'sec':int(g[4])*3600+int(g[5])*60+int(g[6]),'dt':int(g[7]),'saros':int(g[9]),'type':g[10],'qle':g[11],
       'gamma':float(g[12]),'pmag':float(g[13]),'umag':float(g[14]),'pen':num(g[15]),'par':num(g[16]),'tot':num(g[17]),'lat':ll(g[18]),'lon':ll(g[19])}
    types[g[10]]+=1; rows.append(r)
json.dump(rows,open('lunar.json','w')); print(len(rows),sum(1 for r in rows if 500<=r['y']<=1500),types)
print([r for r in rows if r['y']==2018 and r['m']==7])
print([r for r in rows if r['type'][0]=='N'][:1])
