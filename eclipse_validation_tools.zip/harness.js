const fs=require('fs');
const html=fs.readFileSync(''+(process.env.OSSHTML||'/mnt/user-data/outputs/OSS_OLDJAVA_R2026_11.html')+'','utf8');
const blocks={};
const re=/<script type="text\/plain" id="([\w-]+)">/g; let m;
while((m=re.exec(html))){ const i=m.index+m[0].length, j=html.indexOf('</script>',i); blocks[m[1]]=html.slice(i,j); }
global.window=global; global.document={getElementById:id=>blocks[id]!==undefined?{textContent:blocks[id]}:null};
const L=html.split('\n'); const boot=L.slice(36823,36902).join('\n'); // lines 36824..36902
(0,eval)(boot);
const t0=Date.now(); App.init(); console.log('init ms',Date.now()-t0, Object.keys(App.engines).slice(0,8));
module.exports={blocks,E:App.engines};
if(require.main===module){
  const E=App.engines;
  // test: Sun and Moon at 2017-08-21 18:26 TD ~ greatest eclipse
  console.log(Object.getOwnPropertyNames(Object.getPrototypeOf(E.moon)).join(' '));
  console.log(Object.getOwnPropertyNames(Object.getPrototypeOf(E.sun)).join(' '));
  console.log(Object.getOwnPropertyNames(Object.getPrototypeOf(E.ts)).join(' '));
}
